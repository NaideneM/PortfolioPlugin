<?php
defined('MOODLE_INTERNAL') || die();

/*
 * Capabilities for the Portfolio submission plugin.
 *
 * This plugin does not introduce any new capabilities.
 * It relies on existing assignment capabilities.
 */

$capabilities = [];
